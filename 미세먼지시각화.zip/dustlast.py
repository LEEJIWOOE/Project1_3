from flask import Flask, send_from_directory

app = Flask(__name__)

@app.route('/')
def home():
    return "미세먼지 시각화"

@app.route('/html/<path:filename>')
def serve_html(filename):
    # 정적 HTML 파일을 제공하는 라우트
    return send_from_directory('C:/jwlee/project/3_DataScience/team1_3/미세먼지html', filename)

if __name__ == '__main__':
    app.run(debug=True)
