import React, { useState, useEffect } from 'react';

const AutoSwitchingViewer = () => {
    const [currentIndex, setCurrentIndex] = useState(1);
    const totalFiles = 23;  // 총 HTML 파일 수

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentIndex((current) => {
                return current === totalFiles ? 1 : current + 1;
            });
        }, 1000); // 1000ms = 1초

        // 컴포넌트가 언마운트될 때 인터벌을 정리합니다.
        return () => clearInterval(interval);
    }, []);

    return (
        <iframe
            src={`http://localhost:5000/html/heatmap_${currentIndex}.html`}
            style={{ width: '100%', height: '500px', border: 'none' }}
            title="Dynamic HTML Viewer"
        />
    );
};

export default AutoSwitchingViewer;
